package com.example.voicehelper

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.telephony.TelephonyManager

/**
 * सिस्टम चालू होने पर यह पीछे चलता रहता है और फ़ोन आने पर कॉलर का नाम बोल देता है।
 * बंद करने पर यह रुक जाता है।
 */
class VoiceService : Service() {

    private var speaker: Speaker? = null
    private var receiver: BroadcastReceiver? = null
    private var lastAnnounced: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        speaker = Speaker(this)

        receiver = object : BroadcastReceiver() {
            @Suppress("DEPRECATION")
            override fun onReceive(context: Context, intent: Intent) {
                val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
                val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                when (state) {
                    TelephonyManager.EXTRA_STATE_RINGING -> onRinging(number)
                    TelephonyManager.EXTRA_STATE_IDLE,
                    TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                        Prefs.setRinging(context, false)
                        lastAnnounced = null
                    }
                }
            }
        }
        val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
    }

    private fun onRinging(number: String?) {
        Prefs.setRinging(this, true)
        val hasLogPermission =
            checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED

        if (number != null) {
            if (number == lastAnnounced) return
            lastAnnounced = number
            val name = ContactsHelper.nameFor(this, number)
                ?: number.filter { it.isDigit() }.toCharArray().joinToString(" ")
            Prefs.setLastCaller(this, name)
            speaker?.speak("$name का फ़ोन आ रहा है")
        } else if (!hasLogPermission && lastAnnounced != "unknown") {
            lastAnnounced = "unknown"
            Prefs.setLastCaller(this, null)
            speaker?.speak("किसी का फ़ोन आ रहा है। नंबर बताने के लिए कॉल लॉग की अनुमति दो।")
        }
        // अनुमति है पर नंबर अभी null: अगला संदेश नंबर के साथ आएगा, इंतज़ार करो
    }

    private fun startAsForeground() {
        val channelId = "vh_service"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "आवाज़ सहायक", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = Notification.Builder(this, channelId)
            .setContentTitle("आवाज़ सहायक चालू है")
            .setContentText("फ़ोन आने पर कॉलर का नाम बोलूँगा")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        receiver?.let { unregisterReceiver(it) }
        receiver = null
        speaker?.shutdown()
        speaker = null
        super.onDestroy()
    }
}
