package com.example.voicehelper

import android.content.Context
import android.content.Intent

/** पूरे सिस्टम को चालू या बंद करने का एक ही रास्ता (ऐप का स्विच और होम स्क्रीन का बटन दोनों यही इस्तेमाल करते हैं)। */
object Power {
    fun set(c: Context, on: Boolean) {
        Prefs.setOn(c, on)
        val svc = Intent(c, VoiceService::class.java)
        if (on) {
            try {
                c.startForegroundService(svc)
            } catch (e: Exception) {
                // कुछ फ़ोनों में बैकग्राउंड से शुरू होने पर रोक होती है; ऐप खोलकर स्विच दबाओ
            }
        } else {
            Prefs.setRinging(c, false)
            c.stopService(svc)
        }
        ToggleWidget.refresh(c)
    }
}
