package com.example.voicehelper

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract

/** कॉन्टैक्ट में नाम से नंबर और नंबर से नाम ढूँढने का काम। */
object ContactsHelper {

    private fun canRead(c: Context) =
        c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    /** नंबर से कॉन्टैक्ट का नाम (न मिले तो null)। */
    fun nameFor(c: Context, number: String): String? {
        if (!canRead(c)) return null
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )
        c.contentResolver.query(
            uri,
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
            null, null, null
        )?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    /** नाम (या उसके मिलते-जुलते रूप) से (नाम, नंबर) की सूची। */
    fun findByName(c: Context, names: List<String>): List<Pair<String, String>> {
        if (!canRead(c)) return emptyList()
        val out = LinkedHashMap<String, String>()
        for (n in names) {
            c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$n%"),
                null
            )?.use {
                while (it.moveToNext()) {
                    val name = it.getString(0) ?: continue
                    val num = it.getString(1) ?: continue
                    if (!out.containsKey(name)) out[name] = num
                }
            }
        }
        return out.map { it.key to it.value }
    }
}
