package com.example.voicehelper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var speaker: Speaker
    private lateinit var commands: CommandHandler
    private lateinit var status: TextView
    private lateinit var toggle: Switch
    private lateinit var mic: Button
    private var recognizer: SpeechRecognizer? = null
    private var listenAfterPermission = false
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }

        toggle = Switch(this).apply {
            text = "पूरा सिस्टम चालू / बंद   "
            textSize = 20f
            isChecked = Prefs.isOn(this@MainActivity)
        }

        mic = Button(this).apply {
            text = "🎤  बोलो"
            textSize = 28f
            setBackgroundColor(Color.parseColor("#1565C0"))
            setTextColor(Color.WHITE)
        }

        status = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            text = if (Prefs.isOn(this@MainActivity)) "सिस्टम चालू है" else "सिस्टम बंद है"
        }

        val micParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 360
        ).apply { setMargins(0, 64, 0, 64) }

        root.addView(toggle)
        root.addView(mic, micParams)
        root.addView(status)
        setContentView(root)

        speaker = Speaker(this)
        commands = CommandHandler(this, speaker) { msg -> status.text = msg }

        toggle.setOnCheckedChangeListener { _, on ->
            if (on) requestMissingPermissions()
            Power.set(this, on)
            if (on) {
                status.text = "सिस्टम चालू है"
            } else {
                stopListening()
                status.text = "सिस्टम बंद है"
            }
        }
        mic.setOnClickListener { startListening() }

        if (intent?.getBooleanExtra("listen", false) == true) {
            ui.postDelayed({ startListening() }, 400)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        toggle.isChecked = Prefs.isOn(this)
        if (intent?.getBooleanExtra("listen", false) == true) {
            ui.postDelayed({ startListening() }, 400)
        }
    }

    override fun onResume() {
        super.onResume()
        // विजेट से बदला हो तो स्विच भी अपडेट हो जाए
        if (toggle.isChecked != Prefs.isOn(this)) toggle.isChecked = Prefs.isOn(this)
    }

    private fun neededPermissions(): List<String> {
        val list = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    private fun requestMissingPermissions(): Boolean {
        val need = neededPermissions()
        if (need.isEmpty()) return true
        requestPermissions(need.toTypedArray(), 1)
        return false
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (listenAfterPermission &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            listenAfterPermission = false
            startListening()
        }
    }

    private fun startListening() {
        if (!Prefs.isOn(this)) {
            val m = "सिस्टम बंद है। पहले चालू करो।"
            status.text = m
            speaker.speak(m)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            listenAfterPermission = true
            requestMissingPermissions()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "इस फ़ोन में आवाज़ पहचानने की सुविधा नहीं मिली (Google ऐप चाहिए)"
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    status.text = "सुन रहा हूँ... बोलो"
                }

                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (text.isNullOrBlank()) {
                        status.text = "कुछ सुनाई नहीं दिया, फिर बोलो"
                    } else {
                        status.text = "सुना: $text"
                        commands.handle(text)
                    }
                }

                override fun onError(error: Int) {
                    status.text = "समझ नहीं आया, फिर से बोलो"
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer?.startListening(i)
    }

    private fun stopListening() {
        recognizer?.cancel()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        speaker.shutdown()
        super.onDestroy()
    }
}
