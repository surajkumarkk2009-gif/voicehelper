package com.example.voicehelper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import java.util.Calendar

/**
 * बोली हुई बात (टेक्स्ट) को समझकर काम करता है:
 *   1) अलार्म लगाना   2) किसी को कॉल करना   3) बताना कि किसका फ़ोन आ रहा है
 * इसके लिए इंटरनेट या API key नहीं चाहिए।
 */
class CommandHandler(
    private val act: Activity,
    private val speaker: Speaker,
    private val onSay: (String) -> Unit
) {

    private fun say(msg: String) {
        onSay(msg)
        speaker.speak(msg)
    }

    private fun norm(s: String) =
        s.lowercase().replace("़", "").trim() // नुक़्ता हटाकर (फ़ोन -> फोन)

    // नाम के मिलते-जुलते रूप
    private val aliases = listOf(
        listOf("dad", "daddy", "papa", "पापा", "डैड", "डैडी", "पिताजी", "पिता"),
        listOf("mom", "mummy", "mama", "mother", "मम्मी", "मॉम", "मम्मा", "मां", "माँ", "माता"),
        listOf("bhai", "brother", "भाई", "भैया", "भइया"),
        listOf("didi", "sister", "दीदी", "बहन")
    )

    private val stopWords = setOf(
        "कॉल", "काल", "call", "फोन", "phone", "dial", "डायल", "करो", "कर", "दो", "लगाओ", "लगा",
        "को", "मुझे", "my", "माई", "मेरे", "मेरा", "जरा", "please", "प्लीज", "से", "बात",
        "करवाओ", "कराओ", "मिलाओ", "मिला", "the", "to", "एक"
    )

    private val hindiNums = listOf(
        "ग्यारह" to 11, "बारह" to 12, "पांच" to 5, "पाँच" to 5, "पाच" to 5,
        "एक" to 1, "दो" to 2, "तीन" to 3, "चार" to 4, "छह" to 6, "छः" to 6,
        "छे" to 6, "सात" to 7, "आठ" to 8, "नौ" to 9, "दस" to 10
    )

    fun handle(raw: String) {
        val t = norm(raw)
        when {
            isCallerQuestion(t) -> askCaller()
            t.contains("अलार्म") || t.contains("alarm") -> setAlarm(t)
            hasAny(t, "कॉल", "काल", "call", "फोन", "phone", "dial", "डायल") -> makeCall(t)
            else -> say("समझ नहीं आया। अलार्म लगाओ, किसी को कॉल करो, या पूछो किसका फ़ोन आ रहा है।")
        }
    }

    private fun hasAny(t: String, vararg words: String) = words.any { t.contains(it) }

    // ---------- किसका फ़ोन ----------
    private fun isCallerQuestion(t: String) =
        hasAny(t, "किसका", "कौन", "who", "किसकी") &&
            hasAny(t, "फोन", "कॉल", "काल", "call", "phone")

    private fun askCaller() {
        val ringing = Prefs.isRinging(act)
        val who = Prefs.lastCaller(act)
        say(
            when {
                ringing && who != null -> "$who का फ़ोन आ रहा है"
                ringing -> "फ़ोन आ रहा है, पर नंबर पता नहीं चला"
                who != null -> "अभी कोई फ़ोन नहीं आ रहा। आख़िरी फ़ोन $who का था"
                else -> "अभी कोई फ़ोन नहीं आ रहा"
            }
        )
    }

    // ---------- कॉल ----------
    private fun makeCall(t: String) {
        val tokens = t.replace(Regex("[,.!?।:]"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() && it !in stopWords }
        val name = tokens.joinToString(" ").trim()
        if (name.isEmpty()) {
            say("किसे कॉल करना है?")
            return
        }
        if (act.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            say("कॉल की अनुमति नहीं है। ऐप की सेटिंग में फ़ोन की अनुमति दो।")
            return
        }

        val group = aliases.firstOrNull { g -> g.any { norm(it) == name || name.contains(norm(it)) } }
        val searchNames = group ?: listOf(name)

        // अगर बोला हुआ ही नंबर है
        val digits = name.replace(" ", "")
        val matches: List<Pair<String, String>> =
            if (digits.length >= 6 && digits.all { it.isDigit() }) listOf(digits to digits)
            else ContactsHelper.findByName(act, searchNames)

        when {
            matches.isEmpty() -> say("$name नाम का कॉन्टैक्ट नहीं मिला")
            matches.size > 1 -> say(
                "कई नाम मिले: " + matches.take(4).joinToString(", ") { it.first } +
                    "। पूरा नाम बोलो।"
            )
            else -> {
                val (who, number) = matches[0]
                say("$who को कॉल लगा रहा हूँ")
                act.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
            }
        }
    }

    // ---------- अलार्म ----------
    private fun setAlarm(t: String) {
        val time = parseTime(t)
        if (time == null) {
            say("समय समझ नहीं आया। जैसे बोलो: सुबह 6 बजे का अलार्म लगाओ।")
            return
        }
        val (h, m) = time
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "आवाज़ सहायक")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        try {
            act.startActivity(i)
            say("ठीक है, ${spoken(h, m)} का अलार्म लगा दिया")
        } catch (e: Exception) {
            say("अलार्म ऐप नहीं खुल पाया")
        }
    }

    private fun spoken(h: Int, m: Int): String {
        val period = when (h) {
            in 4..11 -> "सुबह"
            in 12..15 -> "दोपहर"
            in 16..19 -> "शाम"
            else -> "रात"
        }
        val h12 = if (h % 12 == 0) 12 else h % 12
        return if (m > 0) "$period $h12 बजकर $m मिनट" else "$period $h12 बजे"
    }

    /** "सुबह 6 बजे", "शाम 5:30", "रात दस बजे", "साढ़े सात बजे" जैसी बातें समझता है। */
    private fun parseTime(t: String): Pair<Int, Int>? {
        var hour: Int? = null
        var min = 0

        val md = Regex("(\\d{1,2})\\s*(?:[:.]\\s*(\\d{2}))?").find(t)
        if (md != null) {
            hour = md.groupValues[1].toInt()
            if (md.groupValues[2].isNotEmpty()) min = md.groupValues[2].toInt()
        } else {
            for ((w, v) in hindiNums) {
                if (Regex("(^|\\s)$w\\s*(बजे|बजकर)").containsMatchIn(t)) {
                    hour = v
                    break
                }
            }
        }
        if (hour == null) return null

        if (t.contains("साढे")) min = 30
        if (t.contains("सवा")) min = 15
        if (t.contains("पौने")) {
            hour = if (hour == 1) 12 else hour - 1
            min = 45
        }

        if (hour > 12) {
            // 24 घंटे वाला समय जैसे 18:30
        } else {
            val isAm = t.contains("सुबह") || t.contains("सवेरे") || Regex("\\bam\\b").containsMatchIn(t)
            val isPm = Regex("\\bpm\\b").containsMatchIn(t)
            hour = when {
                isAm -> hour % 12
                t.contains("दोपहर") -> if (hour in 1..5) hour + 12 else hour
                t.contains("शाम") -> hour % 12 + 12
                t.contains("रात") -> if (hour in 6..11) hour + 12 else if (hour == 12) 0 else hour
                isPm -> hour % 12 + 12
                else -> {
                    // कुछ नहीं बोला: जो समय सबसे जल्दी आने वाला है वही चुनो
                    val now = Calendar.getInstance()
                    val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                    val c1 = hour % 12
                    val c2 = hour % 12 + 12
                    fun diff(c: Int) = (c * 60 + min - nowMin + 1440) % 1440
                    if (diff(c1) <= diff(c2)) c1 else c2
                }
            }
        }
        if (hour !in 0..23 || min !in 0..59) return null
        return hour to min
    }
}
