package com.example.voicehelper

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** होम स्क्रीन का विजेट: एक बटन से पूरा सिस्टम चालू/बंद, और एक 🎤 बटन बोलने के लिए। */
class ToggleWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            Power.set(context, !Prefs.isOn(context))
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.example.voicehelper.TOGGLE"

        fun build(c: Context): RemoteViews {
            val on = Prefs.isOn(c)
            val v = RemoteViews(c.packageName, R.layout.widget_toggle)

            v.setTextViewText(
                R.id.w_toggle,
                if (on) "चालू ✅\nबंद करने के लिए दबाओ" else "बंद ⛔\nचालू करने के लिए दबाओ"
            )
            v.setInt(
                R.id.w_toggle, "setBackgroundColor",
                if (on) 0xFF2E7D32.toInt() else 0xFFB71C1C.toInt()
            )

            val toggle = PendingIntent.getBroadcast(
                c, 1,
                Intent(c, ToggleWidget::class.java).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.w_toggle, toggle)

            val mic = PendingIntent.getActivity(
                c, 2,
                Intent(c, MainActivity::class.java)
                    .putExtra("listen", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.w_mic, mic)
            return v
        }

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, ToggleWidget::class.java))
            for (id in ids) m.updateAppWidget(id, build(c))
        }
    }
}
