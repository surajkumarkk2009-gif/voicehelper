package com.example.voicehelper

import android.content.Context

/** ऐप की छोटी-छोटी सेटिंग्स (चालू/बंद, आख़िरी कॉलर) यहाँ सेव होती हैं। */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("vh", Context.MODE_PRIVATE)

    fun isOn(c: Context): Boolean = sp(c).getBoolean("on", false)
    fun setOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("on", v).apply()

    fun isRinging(c: Context): Boolean = sp(c).getBoolean("ringing", false)
    fun setRinging(c: Context, v: Boolean) = sp(c).edit().putBoolean("ringing", v).apply()

    fun lastCaller(c: Context): String? = sp(c).getString("caller", null)
    fun setLastCaller(c: Context, v: String?) = sp(c).edit().putString("caller", v).apply()
}
